﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace EmployeeLibrary
{
    public class Employees
    {
        ArrayList employeeList = new ArrayList();
        public Employees(string csv)
        {
            try
            {
                ArrayList cleanedData = new ArrayList();
                if (string.IsNullOrEmpty(csv) || !(csv is string))
                {
                    throw new Exception("csv cannot be null");

                }

                /**
                 *In CSV (Comma Separated Values), each line corresponds to a row, and columns are separated by a comma.
                 * We first divide data into rows so that we may and save the individual row as an array.
                 */


                //string[] datarows = csv.Split(new[] { Environment.NewLine },StringSplitOptions.None);
                string[] datarows = csv.Split(
                        new[] { "\r\n", "\r", "\n" },
                        StringSplitOptions.RemoveEmptyEntries
                    );


                /**
                 * After we have the rows in an array as words separated by commas, we split the words rows into arrays.
                 * The purpose of doing this is to be able to validate each data separately.
                 **/
                int CEOCount = 0;
                ArrayList filteredData = new ArrayList();
                ArrayList savedEmployees = new ArrayList();
                ArrayList managers = new ArrayList(); //List of managers
                ArrayList juniorEmployees = new ArrayList(); //List of junior employees
                ArrayList ceo = new ArrayList(); //List of ceo

                foreach (string row in datarows)
                {
                    
                    string[] data = row.Split(',');

                    
                    

                    /*
                     *Validates number of columns in csv
                     */
                    int ColumnCount = row.Split(',').Length;
                    if (ColumnCount != 3)
                    {
                        throw new Exception("CSV value must have 3 values in each row");
                    }

                    /*
                     *Validates if employees salaries are valid
                     */
                    string employeeSalary = Convert.ToString(data[2]);
                        int Salary=0;
                        if (!(Int32.TryParse(employeeSalary, out Salary)))
                        {
                            throw new Exception("Employees salaries must be a valid integer");
                        }

                    /*
                     *Validates employee reports only to one manager
                     */                 
                        if (juniorEmployees.Contains(data[0]))
                        throw new Exception("Employee value is duplicated this may be as a result of an employee reporting to more than one manager");
                    /*
                     *Validates there is only once CEO in the company
                     */
                    if (string.IsNullOrEmpty(data[1]))
                    {
                        ceo.Add(data[1]);
                        CEOCount++;
                        
                        if(CEOCount > 1)
                            throw new Exception("We can't determine who is the CEO kindly look through your data");

                    }             

                    filteredData.Add(data);                    
                    juniorEmployees.Add(data[0]);
                    managers.Add(data[1]);
                    employeeList.Add(data);                    

                    ////// check for circular reference
                    for (var i = 0; i < filteredData.Count; i++)
                    {
                        object [] employeeData = filteredData[i] as object [];
                        //var employeeData = filteredData[i] as ArrayList;
                        var employeeManager = employeeData[1] as string;
                        int index = employeeList.IndexOf(employeeManager);

                        if (index != -1)
                        {
                            var managerData = filteredData[index] as ArrayList;
                            var topManager = managerData[1] as string;

                            if ((managers.Contains(topManager.Trim()) && !ceo.Contains(topManager.Trim()))
                                || juniorEmployees.Contains(topManager.Trim()))
                            {
                                throw new Exception("Circular reference error");
                            }
                        }
                    }                

                }

                // check if all managers are employess
                foreach (string manager in managers)
                {
                    if (!juniorEmployees.Contains(manager.Trim()) && !string.IsNullOrEmpty(manager))
                    {
                        throw new Exception("The list is incomplete it seems there are some managers who aren't listed in employess cell");
                    }
                }

            }

            catch(Exception e)
            {
                throw e;
            }
        }

  /*
  *Return salary budgets of a specified manager
  * **/

        public int managerSalaryBudget(string manageName)
        {
            int totalManagerSalary = 0;
            foreach (object [] employee in employeeList)
            {
                var name = employee[1] as string;
                var employeeSalary = employee[2] as string;
                var employeName = employee[0] as string;
                if (name.Trim() == manageName.Trim() || employeName.Trim() == manageName.Trim())
                {
                    totalManagerSalary += Convert.ToInt32(employeeSalary);
                }
            }
            return totalManagerSalary;
        }

    }
 
}
