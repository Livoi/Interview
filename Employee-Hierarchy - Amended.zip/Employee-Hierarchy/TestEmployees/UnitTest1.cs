using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using EmployeeLibrary;

namespace TestEmployees
{
	[TestClass]

	public class UnitTest1
	{
        [TestMethod]
        public void TestManagerBurgetsReturnsCorrect()
        {

            Employees testEmployee = new Employees("" +
                "John, James, 100" + "\n" +
                //Uncomment next line to check ever manager/ceo is employee
                //"Joyce, Drake, 300" + "\n" +
                //Uncomment next line to check if csv has 3 columns
                //"Joyce, James, 300,test" + "\n" +
                //Uncomment next line to check if salary column is not integer
                //"Joyce, James, three" + "\n" +
                "James, Eve, 100" + "\n" +
                "Eve, Ken, 1900" + "\n" +
                "Thelma,, 1000" + "\n" +
                //Uncomment next line to check there is only once CEO in the company validation
                //"John,, 1000" + "\n" +
                "Ken, Thelma, 1900" + "\n" +
                "Peter, salasia, 1900" + "\n" +
                //Uncomment next line to check employee reporting to more than 0ne manager
                //"Ken,salasia, 1000" + "\n" +
                "salasia, James, 1900" + "\n" +
                "Tom, Thelma, 1900" + "\n" +
                ////Uncomment next two lines to test circular refernece
                //"Joyce, James, 1900" + "\n" +
                //"James, Joyce, 1000" + "\n" +
                "");
            
            Assert.AreEqual(2100, testEmployee.managerSalaryBudget("James"));

        }
    }
}